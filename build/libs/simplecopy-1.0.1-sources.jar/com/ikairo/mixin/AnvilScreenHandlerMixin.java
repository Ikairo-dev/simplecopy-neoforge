package com.ikairo.mixin;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.ItemCombinerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.apache.commons.lang3.StringUtils;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AnvilMenu.class)
public abstract class AnvilScreenHandlerMixin extends ItemCombinerMenu {

    @Shadow
    private String newItemName;

    @Shadow
    @Final
    private DataSlot levelCost;

    @Shadow public abstract void createResult();

    @Unique
    private boolean isDuplicating;

    @Unique
    private boolean isRemovingItem;

    public AnvilScreenHandlerMixin(int syncId, Inventory inventory) {
        super(null, syncId, inventory, null);
    }

    @Inject(method = "updateResult()V", at = @At("HEAD"))
    protected void checkIsDuplicating(CallbackInfo ci) {
        if(!isRemovingItem) {
            isDuplicating = this.inputSlots.getItem(0).is(Items.BOOK)
                    && this.inputSlots.getItem(1).has(DataComponents.STORED_ENCHANTMENTS);
        }
    }

    @Redirect(method = "updateResult()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;getCount()I"))
    private int onGetItemStackCount(ItemStack stack) {
        if (isDuplicating) {
            return 1;
        } else {
            return stack.getCount();
        }
    }

    @ModifyVariable(method = "updateResult()V", at = @At("STORE"), ordinal = 3)
    private boolean onStoreIsEnchantAcceptable(boolean isAcceptable) {
        if (isDuplicating) {
            return true;
        } else {
            return isAcceptable;
        }
    }

    @Inject(method = "updateResult()V", at = @At(value = "INVOKE", target = "Lnet/minecraft/inventory/CraftingResultInventory;setStack(ILnet/minecraft/item/ItemStack;)V", shift = At.Shift.AFTER))
    private void afterSetResult(CallbackInfo ci) {
        if (isDuplicating && (!isRemovingItem || this.inputSlots.getItem(0).is(Items.BOOK))) {
            ItemStack result = this.inputSlots.getItem(1).copy();

            if (!StringUtils.isBlank(this.newItemName)
                    && !StringUtils.equals(this.newItemName, this.inputSlots.getItem(0).getHoverName().getString())
                    && !StringUtils.equals(this.newItemName, this.inputSlots.getItem(0).getHoverName().getString())) {
                result.set(DataComponents.CUSTOM_NAME, Component.literal(this.newItemName));
            }

            this.resultSlots.setItem(0, result);
        }
    }

    @Redirect(method = "onTakeOutput", at = @At(value = "INVOKE", target = "Lnet/minecraft/inventory/Inventory;setStack(ILnet/minecraft/item/ItemStack;)V", ordinal = 0))
    private void decrementWhenDuplicating(Container instance, int i, ItemStack itemStack) {
        isRemovingItem = true;
        if (this.inputSlots.getItem(0).getCount() > 1 && this.inputSlots.getItem(0).is(Items.BOOK) && !this.inputSlots.getItem(1).isEmpty()) {
            if (player instanceof ServerPlayer) {
                this.inputSlots.getItem(0).shrink(1);
            }
            this.createResult();
        } else {
            this.inputSlots.setItem(0, ItemStack.EMPTY);
        }
        isRemovingItem = false;
    }

    @Redirect(method = "onTakeOutput", at = @At(value = "INVOKE", target = "Lnet/minecraft/inventory/Inventory;setStack(ILnet/minecraft/item/ItemStack;)V", ordinal = 3))
    private void doNotSetInputSlot2Empty(Container instance, int i, ItemStack itemStack) {
        if (!isDuplicating) {
            this.inputSlots.setItem(1, ItemStack.EMPTY);
        }
    }

    @Redirect(method = "onTakeOutput", at = @At(value = "INVOKE", target = "Lnet/minecraft/screen/Property;set(I)V"))
    private void doNotResetLevelCost(DataSlot instance, int i) {
        if (!isDuplicating || !this.inputSlots.getItem(0).is(Items.BOOK)) {
            instance.set(i);
        }
    }

    public ItemStack quickMoveStack(Player player, int slot) {
        if (this.inputSlots.getItem(0).is(Items.BOOK)
                && slot == 2
                && !this.inputSlots.getItem(1).isEmpty()
                && !player.hasInfiniteMaterials()
                && player.experienceLevel < this.levelCost.get()) {
            return this.inputSlots.getItem(slot);
        }
        return super.quickMoveStack(player, slot);
    }
}